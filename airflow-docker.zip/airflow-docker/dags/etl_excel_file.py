from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime
import pandas as pd

def process_excel_files():
    # Đọc file dữ liệu gốc
    sankey_sample_data = pd.read_excel('/opt/airflow/data/sankey_data_sample.xlsx', sheet_name='sankey')[['acountid','event_feature','timestamp','data_date']]
    event_group = pd.read_excel('/opt/airflow/data/sankey_data_sample.xlsx', sheet_name='event_group')
    event_tracking = pd.read_excel('/opt/airflow/data/sankey_data_sample.xlsx', sheet_name='event_tracking')

    # Xử lý dữ liệu tại từng file gốc - chuyển tên event thành dạng chữ lower
    sankey_sample_data['event_feature']=sankey_sample_data['event_feature'].str.lower()
    event_group['event_feature']=event_group['event_feature'].str.lower()
    event_tracking['event_feature']=event_tracking['event_feature'].str.lower()

    # Left join lấy nhóm event, nếu không có thì để giá trị 'Unknown'
    df = pd.merge(sankey_sample_data,event_group,how='left',on='event_feature')

    # Tiếp tục Left join lấy screen, nếu không có thì để giá trị 'Unknown'
    df = pd.merge(df,event_tracking[['event_feature','screen']],how='left',on='event_feature')

    # Tạo hàm xử lý adhoc với các dòng có cả event_group và screen đều null
    def categorize_event_feature(event_feature, event_group, screen):
        if pd.isna(event_group) and pd.isna(screen):
            if event_feature.startswith('bond_'):
                return 'bond'
            elif event_feature.startswith('asset_'):
                return 'asset'
            elif event_feature.startswith('stock_'):
                return 'stock_detail'
            elif event_feature.startswith('searchstock'):
                return 'Cổ phiếu'
            elif event_feature.startswith('buy_sell_confirm'):
                return 'validate_stock_order'
            elif event_feature.startswith('market_portfolio_'):
                return 'market'
            elif event_feature.startswith('1stock'):
                return 'stock_detail'
            elif 'topup' in event_feature:
                return 'topup'
            elif event_feature.startswith('log_in'):
                return 'log_in'
            elif event_feature.startswith('home_'):
                return 'Home'
            elif event_feature.startswith('money_'):
                return 'money'
            elif event_feature.startswith('smartqr_'):
                return 'smartqr'
            else:
                return event_group
        return event_group

    # Xử lý tạo cột event_grp với các rule xử lý adhoc
    df['event_grp'] = df.apply(lambda x: categorize_event_feature(x['event_feature'],x['event_group'],x['screen']),axis=1)

    # Update giá trị cột event_grp theo giá trị cột screen nếu null
    df['event_grp'] = df['event_group'].fillna(df['screen'])

    # Lưu kết quả ra file Excel
    df.to_excel('/opt/airflow/data/sankey_data_sample_transformed.xlsx')

# Khởi tạo DAG
with DAG(
    'excel_processing_dag',
    default_args={'owner': 'airflow', 'retries': 1},
    schedule_interval=None,  # Lệnh chạy theo yêu cầu
    start_date=datetime(2025, 5, 1),
    catchup=False
) as dag:
    
    # Định nghĩa PythonOperator để xử lý file
    process_task = PythonOperator(
        task_id='process_excel_files',
        python_callable=process_excel_files
    )